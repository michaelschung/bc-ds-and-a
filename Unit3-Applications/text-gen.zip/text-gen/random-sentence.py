words = []

with open('txt/tswift.txt', 'r') as f:
    for line in f:
        # Remove whitespace from the ends
        stripped_line = line.strip()
        # Split the line into a list of words
        line_words = stripped_line.split()
        # Add each word to our master list
        words.extend(line_words)

###### PROBLEM ######

# Given the above list of words, which has been read in from a file, generate a “sentence” of 20 words by repeatedly choosing a random word from the list.
